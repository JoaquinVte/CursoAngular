export interface IEvent {
    title: string;
    image: string;
    date: string;
    description: string;
    price: number;
}
