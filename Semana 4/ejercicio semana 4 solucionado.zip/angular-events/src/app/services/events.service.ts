import { Injectable } from '@angular/core';
import { IEvent } from '../interfaces/i-event';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { SERVICES } from '../app.constants';
import { EventsResponse, EventResponse, OkResponse } from '../interfaces/responses';

@Injectable({
  providedIn: 'root'
})
export class EventsService {

  constructor(private http: HttpClient) { }

  getEvents(): Observable<IEvent[]> {
    return this.http.get<EventsResponse>(SERVICES + '/events').pipe(
      map(resp => {
        if (!resp.ok) { throw resp.error; }
        return resp.events;
      })
    );
  }

  addEvent(event: IEvent): Observable<IEvent> {
    return this.http.post<EventResponse>(SERVICES + '/events', event).pipe(
      map(resp => {
        if (!resp.ok) { throw resp.errors; }
        return resp.event;
      })
    );
  }

  deleteEvent(idEvent: number): Observable<boolean> {
    return this.http.delete<OkResponse>(SERVICES + '/events/' + idEvent).pipe(
      map(resp => {
        if (!resp.ok) { throw resp.error; }
        return resp.ok;
      })
    );
  }
}
