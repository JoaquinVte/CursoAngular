export const SERVICES = 'http://arturober.com/angular-semana4';
