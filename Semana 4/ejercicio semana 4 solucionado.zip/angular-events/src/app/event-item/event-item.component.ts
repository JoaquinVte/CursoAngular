import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { EventsService } from '../services/events.service';
import { IEvent } from '../interfaces/i-event';

@Component({
  selector: 'ae-event-item',
  templateUrl: './event-item.component.html',
  styleUrls: ['./event-item.component.css']
})
export class EventItemComponent implements OnInit {
  @Input() event: IEvent;
  @Output() deleted = new EventEmitter<void>();

  constructor(private eventsService: EventsService) { }

  ngOnInit() {
  }

  deleteEvent() {
    this.eventsService.deleteEvent(this.event.id).subscribe(
      ok => this.deleted.emit(),
      error => console.error(error)
    );
  }
}
