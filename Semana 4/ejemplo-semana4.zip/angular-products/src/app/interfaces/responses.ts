import { IProduct } from './i-product';

export interface ResponseProducts {
  products: IProduct[];
}

export interface OkResponse {
  ok: boolean;
  error?: string;
}
