import { Component, OnInit } from '@angular/core';
import { IProduct } from '../interfaces/i-product';
import { ProductsService } from '../services/products.service';

@Component({
  selector: 'product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  showImage = true;
  filterSearch = '';
  title = 'Mi lista de productos';
  headers = {desc: 'Producto', price: 'Precio', avail: 'Disponible', image: 'Imagen', 'rating': 'Puntuación'};

  products: IProduct[] = [];

  constructor(private productsService: ProductsService) { }

  ngOnInit() {
    this.productsService.getProducts().subscribe(
      products => this.products = products, // ok
      error => console.error(error), // error
      () => console.log('Carga de productos completada!') // "Finally"
    );
  }

  toggleImage() {
    this.showImage = !this.showImage;
  }

}
