import { GmapsAutocompleteDirective } from './gmaps-autocomplete.directive';

describe('GmapsAutocompleteDirective', () => {
  it('should create an instance', () => {
    const directive = new GmapsAutocompleteDirective();
    expect(directive).toBeTruthy();
  });
});
