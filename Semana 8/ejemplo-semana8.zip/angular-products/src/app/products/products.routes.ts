import { Route } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductDetailGuard } from './guards/product-detail.guard';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductDetailResolve } from './guards/product-detail-resolve.guard';
import { LeavePageGuard } from '../guards/leave-page.guard';
import { ProductEditComponent } from './product-edit/product-edit.component';

export const PRODUCTS_ROUTES: Route[] = [
  { path: '', component: ProductListComponent },
  // :id is a parameter (product's id)
  {
    path: ':id',
    canActivate: [ProductDetailGuard],
    component: ProductDetailComponent,
    resolve: {
      product: ProductDetailResolve
    }
  },
  {
    path: 'edit/:id',
    component: ProductEditComponent,
    canActivate: [ProductDetailGuard],
    canDeactivate: [LeavePageGuard],
    resolve: {
      product: ProductDetailResolve
    }
  }
];
