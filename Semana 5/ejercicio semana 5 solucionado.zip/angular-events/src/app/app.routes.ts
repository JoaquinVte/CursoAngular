import { Route } from '@angular/router';
import { EventsShowComponent } from './events-show/events-show.component';
import { EventAddComponent } from './event-add/event-add.component';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { EventDetailResolve } from './guards/event-detail-resolve.guard';

export const APP_ROUTES: Route[] = [
  { path: 'events', component: EventsShowComponent },
  { path: 'events/add', component: EventAddComponent },
  {
    path: 'events/:id',
    component: EventDetailComponent,
    resolve: {
      event: EventDetailResolve
    }
  },
  { path: '', redirectTo: '/events', pathMatch: 'full' },
  { path: '**', redirectTo: '/events', pathMatch: 'full' }
];
