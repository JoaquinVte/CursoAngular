import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'star-rating',
  templateUrl: './star-rating.component.html',
  styleUrls: ['./star-rating.component.css']
})
export class StarRatingComponent implements OnInit {
  @Input() rating: number;
  private auxRating: number;
  @Output() ratingChanged = new EventEmitter<number>();

  constructor() { }

  restoreRating() {
    this.auxRating = this.rating;
  }

  ngOnInit() {
    this.restoreRating();
  }

  setRating() {
    this.ratingChanged.emit(this.auxRating);
  }

}
