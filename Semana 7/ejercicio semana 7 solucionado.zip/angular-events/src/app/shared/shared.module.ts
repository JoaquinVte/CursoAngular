import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForPairsDirective } from './directives/for-pairs.directive';
import { MinDateDirective } from './validators/min-date.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [ForPairsDirective, MinDateDirective],
  exports: [ForPairsDirective, MinDateDirective]
})
export class SharedModule {}
