import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { EventItemComponent } from './event-item/event-item.component';
import { EventAddComponent } from './event-add/event-add.component';
import { EventFilterPipe } from './pipes/event-filter.pipe';
import { EventsShowComponent } from './events-show/events-show.component';
import { EventsService } from './services/events.service';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from '../shared/shared.module';
import { EVENTS_ROUTES } from './events.routes';
import { RouterModule } from '@angular/router';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    SharedModule,
    RouterModule.forChild(EVENTS_ROUTES),
  ],
  declarations: [
    EventsShowComponent,
    EventFilterPipe,
    EventItemComponent,
    EventAddComponent,
    EventDetailComponent
  ],
  providers: [EventsService]
})
export class EventsModule { }
