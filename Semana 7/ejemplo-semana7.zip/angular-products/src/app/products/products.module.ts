import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { ProductListComponent } from './product-list/product-list.component';
import { ProductFilterPipe } from './pipes/product-filter.pipe';
import { ProductItemComponent } from './product-item/product-item.component';
import { ProductDetailResolve } from './guards/product-detail-resolve.guard';
import { ProductDetailGuard } from './guards/product-detail.guard';
import { ProductsService } from './services/products.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { PRODUCTS_ROUTES } from './products.routes';
import { RatingModule } from '../rating/rating.module';
import { MinDateDirective } from '../validators/min-date.directive';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forChild(PRODUCTS_ROUTES),
    RatingModule
  ],
  declarations: [
    ProductDetailComponent,
    ProductEditComponent,
    ProductListComponent,
    ProductFilterPipe,
    ProductItemComponent,
    MinDateDirective

  ],
  providers: [ProductsService, ProductDetailGuard, ProductDetailResolve]
})
export class ProductsModule {}
