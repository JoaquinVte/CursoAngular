import { Injectable } from '@angular/core';
import { IEvent } from '../interfaces/i-event';

@Injectable({
  providedIn: 'root'
})
export class EventsService {

  constructor() { }

  getEvents(): IEvent[] {
    return [{
      title: 'Evento de prueba',
      date: '2019-03-15',
      description: 'Nos lo pasaremos genial',
      image: 'assets/evento1.jpg',
      price: 23.95
    }, {
      title: 'Evento de prueba 2',
      date: '2019-03-21',
      description: 'Este es peor',
      image: 'assets/evento2.jpg',
      price: 15.50
    }];
  }
}
