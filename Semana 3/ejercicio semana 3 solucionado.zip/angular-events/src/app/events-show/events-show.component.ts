import { Component, OnInit } from '@angular/core';
import { IEvent } from '../interfaces/i-event';
import { EventsService } from '../services/events.service';

@Component({
  selector: 'ae-events-show',
  templateUrl: './events-show.component.html',
  styleUrls: ['./events-show.component.css']
})
export class EventsShowComponent implements OnInit {
  search = '';

  events: IEvent[] = [];

  constructor(private eventsService: EventsService) { }

  ngOnInit() {
    this.events = this.eventsService.getEvents();
  }

  addEvent(event: IEvent) {
    this.search = '';
    this.events.push(event);
  }

  orderDate() {
    this.search = '';
    this.events.sort((e1, e2) => e1.date.localeCompare(e2.date));
  }

  orderPrice() {
    this.search = '';
    this.events.sort((e1, e2) => e1.price - e2.price);
  }

  deleteEvent(event: IEvent) {
    this.events = this.events.filter(e => e !== event);
  }
}
