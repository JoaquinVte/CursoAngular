import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'ae-event-item',
  templateUrl: './event-item.component.html',
  styleUrls: ['./event-item.component.css']
})
export class EventItemComponent implements OnInit {
  @Input() event;
  @Output() deleted = new EventEmitter<void>();

  constructor() { }

  ngOnInit() {
  }

  deleteEvent() {
    this.deleted.emit();
  }
}
