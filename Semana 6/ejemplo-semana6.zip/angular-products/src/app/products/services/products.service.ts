import { Injectable } from '@angular/core';
import { IProduct } from '../interfaces/i-product';
import { Observable, throwError } from 'rxjs';
import { map, catchError, retry } from 'rxjs/operators';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ResponseProducts, OkResponse, ResponseProduct } from '../../interfaces/responses';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  private productURL = 'http://arturober.com/products-angular/products';

  constructor(private http: HttpClient) { }

  getProducts(): Observable<IProduct[]> {
    return this.http.get<ResponseProducts>(this.productURL).pipe(
      map(response => response.products),
      catchError((resp: HttpErrorResponse) => throwError(`Error obteniendo productos.
        Código de servidor: ${resp.status}. Mensaje: ${resp.message}`))
    );
  }

  getProduct(id): Observable<IProduct> {
    return this.http.get(this.productURL + `/${id}`).pipe(
        map((resp: ResponseProduct) => resp.product),
        catchError((resp: HttpErrorResponse) => Observable.throw(`Error obteniendo producto ${id}.
        Código de servidor: ${resp.status}. Mensaje: ${resp.message}`))
    );
  }

  changeRating(idProduct: number, rating: number): Observable<boolean> {
    return this.http.put<OkResponse>(this.productURL + '/rating/' + idProduct, {rating: rating}).pipe(
      catchError((resp: HttpErrorResponse) => throwError(`Error cambiando puntuación!.
        Código de servidor: ${resp.status}. Mensaje: ${resp.message}`)),
      map(resp => {
        if (!resp.ok) { throw resp.error; }
        return true;
      })
    );
  }
}
