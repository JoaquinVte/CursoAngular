import { Component, OnInit } from '@angular/core';
import { ComponentDeactivate } from '../../guards/leave-page.guard';

@Component({
  selector: 'product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css']
})
export class ProductEditComponent implements OnInit, ComponentDeactivate {

  constructor() { }

  ngOnInit() {
  }

  canDeactivate() {
    return confirm('¿Quieres abandonar la página?. Los cambios no se guardarán.');
  }

}
