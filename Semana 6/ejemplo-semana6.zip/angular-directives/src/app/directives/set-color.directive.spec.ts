import { SetColorDirective } from './set-color.directive';

describe('SetColorDirective', () => {
  it('should create an instance', () => {
    const directive = new SetColorDirective();
    expect(directive).toBeTruthy();
  });
});
