import { ForFilterDirective } from './for-filter.directive';

describe('ForFilterDirective', () => {
  it('should create an instance', () => {
    const directive = new ForFilterDirective();
    expect(directive).toBeTruthy();
  });
});
