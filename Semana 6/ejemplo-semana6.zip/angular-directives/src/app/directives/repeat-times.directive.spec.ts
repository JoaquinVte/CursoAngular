import { RepeatTimesDirective } from './repeat-times.directive';

describe('RepeatTimesDirective', () => {
  it('should create an instance', () => {
    const directive = new RepeatTimesDirective();
    expect(directive).toBeTruthy();
  });
});
