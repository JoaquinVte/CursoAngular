import { Pipe, PipeTransform } from '@angular/core';
import { IEvent } from '../interfaces/i-event';

@Pipe({
  name: 'eventFilter'
})
export class EventFilterPipe implements PipeTransform {

  transform(events: IEvent[], search: string): IEvent[] {
    return search ? events.filter(e => e.title.toLocaleLowerCase().includes(search.toLocaleLowerCase())) : events;
  }

}
