import { Route } from '@angular/router';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { EventDetailResolve } from './guards/event-detail-resolve.guard';
import { EventAddComponent } from './event-add/event-add.component';
import { EventsShowComponent } from './events-show/events-show.component';

export const EVENTS_ROUTES: Route[] = [
  { path: '', component: EventsShowComponent },
  { path: 'add', component: EventAddComponent },
  {
    path: ':id',
    component: EventDetailComponent,
    resolve: {
      event: EventDetailResolve
    }
  }
];
