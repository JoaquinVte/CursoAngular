import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[forPairs]'
})
export class ForPairsDirective {

  constructor(
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef
  ) {}

  @Input()
  set forPairsOf(array: any[]) {
    this.viewContainer.clear(); // Si cambian los datos de entrada borramos
    for (let i = 0; i < array.length; i += 2) {
      const pair = [array[i]];
      if (i + 1 < array.length) {
        pair.push(array[i + 1]);
      }
      this.viewContainer.createEmbeddedView(this.templateRef, {
        $implicit: pair
      });
    }
  }
}
