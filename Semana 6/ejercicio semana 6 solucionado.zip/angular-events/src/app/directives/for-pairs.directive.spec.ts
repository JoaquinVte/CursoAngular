import { ForPairsDirective } from './for-pairs.directive';

describe('ForPairsDirective', () => {
  it('should create an instance', () => {
    const directive = new ForPairsDirective();
    expect(directive).toBeTruthy();
  });
});
