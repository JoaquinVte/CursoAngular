import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForPairsDirective } from '../directives/for-pairs.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [ForPairsDirective],
  exports: [ForPairsDirective]
})
export class SharedModule {}
